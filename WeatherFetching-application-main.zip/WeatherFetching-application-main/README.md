# WeatherFetching
this is a simple well organized weather web application that uses HTML CSS and Javascript using the Openweathermap.org API. It gives you a Live forecast data such as temperature/Min & Max , Humidity and so on
